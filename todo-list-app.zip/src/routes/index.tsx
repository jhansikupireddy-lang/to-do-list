import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo, type FormEvent } from "react";
import { Check, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Todo List" },
      { name: "description", content: "A simple, beautiful todo list app." },
    ],
  }),
  component: Index,
});

type Todo = { id: string; text: string; done: boolean };
type Filter = "all" | "active" | "done";

function Index() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [text, setText] = useState("");
  const [filter, setFilter] = useState<Filter>("all");

  const remaining = todos.filter((t) => !t.done).length;
  const visible = useMemo(
    () =>
      todos.filter((t) =>
        filter === "all" ? true : filter === "active" ? !t.done : t.done,
      ),
    [todos, filter],
  );

  const add = (e: FormEvent) => {
    e.preventDefault();
    const v = text.trim();
    if (!v) return;
    setTodos((p) => [{ id: crypto.randomUUID(), text: v, done: false }, ...p]);
    setText("");
  };

  const toggle = (id: string) =>
    setTodos((p) => p.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  const remove = (id: string) => setTodos((p) => p.filter((t) => t.id !== id));
  const clearDone = () => setTodos((p) => p.filter((t) => !t.done));

  return (
    <main className="min-h-screen bg-background px-4 py-16">
      <div className="mx-auto w-full max-w-xl">
        <header className="mb-8">
          <h1 className="text-4xl font-semibold tracking-tight text-foreground">
            Todo
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {remaining} {remaining === 1 ? "task" : "tasks"} remaining
          </p>
        </header>

        <form onSubmit={add} className="flex gap-2">
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="What needs to be done?"
            className="h-12"
          />
          <Button type="submit" size="lg" className="h-12 px-4">
            <Plus className="size-4" />
          </Button>
        </form>

        <div className="mt-6 flex items-center gap-1 border-b border-border pb-3">
          {(["all", "active", "done"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-md px-3 py-1 text-sm capitalize transition-colors",
                filter === f
                  ? "bg-secondary text-secondary-foreground"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {f}
            </button>
          ))}
          <button
            onClick={clearDone}
            className="ml-auto text-xs text-muted-foreground hover:text-foreground"
          >
            Clear completed
          </button>
        </div>

        <ul className="mt-2 divide-y divide-border">
          {visible.length === 0 && (
            <li className="py-10 text-center text-sm text-muted-foreground">
              Nothing here yet.
            </li>
          )}
          {visible.map((t) => (
            <li
              key={t.id}
              className="group flex items-center gap-3 py-3"
            >
              <button
                onClick={() => toggle(t.id)}
                className={cn(
                  "flex size-5 shrink-0 items-center justify-center rounded-full border transition-colors",
                  t.done
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-input hover:border-primary",
                )}
                aria-label={t.done ? "Mark as active" : "Mark as done"}
              >
                {t.done && <Check className="size-3" />}
              </button>
              <span
                className={cn(
                  "flex-1 text-sm",
                  t.done && "text-muted-foreground line-through",
                )}
              >
                {t.text}
              </span>
              <button
                onClick={() => remove(t.id)}
                className="text-muted-foreground opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                aria-label="Delete"
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>
      </div>
    </main>
  );
}
